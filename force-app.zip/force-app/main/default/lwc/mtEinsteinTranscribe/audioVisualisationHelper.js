/**
 * ============================================================================
 * Audio Visualization Helper (Default - Enhanced Waveform)
 * ============================================================================
 * 
 * @description     Audio visualization utilities for the Einstein Transcribe LWC.
 *                  This default implementation shows an enhanced waveform with
 *                  dynamic line thickness and color based on audio amplitude.
 * 
 * @usage           Import in LWC:
 *                  import { initializeVisualization, startAnimation, stopAnimation, clearCanvas } 
 *                  from './audioVisualisationHelper';
 * 
 * @alternatives    - audioVisualisationHelper_opt1.js (Circular frequency spectrum)
 *                  - audioVisualisationHelper_opt2.js (Thin waveform)
 *                  - audioVisualisationHelper_opt3.js (Waveform with frequency bars)
 * 
 * @author          Michael Tietze, Principal AI Architect
 * @created         November 2025
 * @contact         mtietze@salesforce.com
 * 
 * ============================================================================
 * COPYRIGHT & CONFIDENTIALITY NOTICE
 * ============================================================================
 * © 2025 Salesforce, Inc. All rights reserved.
 * 
 * This code is the confidential and proprietary information of Salesforce, Inc.
 * It is intended solely for internal use within Salesforce.
 * 
 * DISTRIBUTION RESTRICTION: This code may NOT be shared externally or 
 * distributed outside of Salesforce without explicit written approval 
 * from Michael Tietze (mtietze@salesforce.com).
 * ============================================================================
 */

let animationFrameId = null;

/**
 * @description     Initializes the audio visualization context
 * @param {MediaStream} stream - The audio stream from MediaRecorder
 * @param {HTMLCanvasElement} canvasElement - Canvas element for rendering
 * @returns {Object} Contains audioContext, analyser, and canvasCtx
 */
export function initializeVisualization(stream, canvasElement) {
	if (!canvasElement) {
		throw new Error('Canvas element not found for visualization.');
	}

	const audioContext = new (window.AudioContext || window.webkitAudioContext)();
	const source = audioContext.createMediaStreamSource(stream);
	const analyser = audioContext.createAnalyser();
	analyser.fftSize = 2048; // Higher for better waveform detail
	source.connect(analyser);

	const canvasCtx = canvasElement.getContext('2d');
	clearCanvas(canvasElement, canvasCtx);

	return { audioContext, analyser, canvasCtx };
}

/**
 * @description     Starts the animation loop for waveform drawing
 * @param {AnalyserNode} analyser - Web Audio API analyser node
 * @param {CanvasRenderingContext2D} canvasCtx - Canvas 2D context
 * @param {HTMLCanvasElement} canvasElement - Canvas element
 * @param {Function} isRecordingFn - Function returning current recording state
 */
export function startAnimation(analyser, canvasCtx, canvasElement, isRecordingFn) {
	function animate() {
		if (!isRecordingFn()) return;
		drawWaveform(analyser, canvasCtx, canvasElement);
		animationFrameId = requestAnimationFrame(animate);
	}
	animate();
}

/**
 * @description     Stops the animation loop
 */
export function stopAnimation() {
	if (animationFrameId) {
		cancelAnimationFrame(animationFrameId);
		animationFrameId = null;
	}
}

/**
 * @description     Clears the canvas
 * @param {HTMLCanvasElement} canvasElement - Canvas element
 * @param {CanvasRenderingContext2D} canvasCtx - Canvas 2D context
 */
export function clearCanvas(canvasElement, canvasCtx) {
	canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
}

/**
 * @description     Draws enhanced waveform with dynamic styling
 *                  Line thickness and color vary based on audio amplitude
 * @param {AnalyserNode} analyser - Web Audio API analyser node
 * @param {CanvasRenderingContext2D} canvasCtx - Canvas 2D context
 * @param {HTMLCanvasElement} canvasElement - Canvas element
 * @private
 */
function drawWaveform(analyser, canvasCtx, canvasElement) {
	const { width, height } = canvasElement;
	canvasCtx.clearRect(0, 0, width, height);

	const bufferLength = analyser.fftSize;
	const dataArray = new Float32Array(bufferLength);
	analyser.getFloatTimeDomainData(dataArray);

	// Increased default line width
	canvasCtx.lineWidth = 3;
	canvasCtx.strokeStyle = '#00ffcc'; // Cyan color

	canvasCtx.beginPath();

	const sliceWidth = width / bufferLength;
	let x = 0;

	dataArray.forEach((data, i) => {
		const v = data * 0.5 + 0.5; // Normalize to 0-1
		const y = v * height;

		if (i === 0) {
			canvasCtx.moveTo(x, y);
		} else {
			canvasCtx.lineTo(x, y);
		}

		x += sliceWidth;

		// Enhanced line thickness variation for volume peaks
		const amplitude = Math.abs(data);
		canvasCtx.lineWidth = 2 + amplitude * 5; // Increased multiplier

		// Enhanced color change for volume peaks
		const hue = 180 + amplitude * 180; // Shift hue more dramatically
		canvasCtx.strokeStyle = `hsl(${hue}, 100%, 50%)`;

		// Add small circles for prominent peaks
		if (amplitude > 0.8) {
			canvasCtx.fillStyle = 'white';
			canvasCtx.beginPath();
			canvasCtx.arc(x, y, 3, 0, Math.PI * 2);
			canvasCtx.fill();
		}
	});

	canvasCtx.lineTo(canvasElement.width, canvasElement.height / 2);
	canvasCtx.stroke();
}